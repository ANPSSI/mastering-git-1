A platform for students and teachers
